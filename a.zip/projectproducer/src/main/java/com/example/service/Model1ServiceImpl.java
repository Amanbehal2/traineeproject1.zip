package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Repo.Model1Repo;
import com.example.bean1.Model1;
@Service
@Transactional

public class Model1ServiceImpl implements Model1Service{

	@Autowired
	Model1Repo model1;
	
	@Override
	public int adduser(Model1 modeluser) {
		 model1.save(modeluser);
		return modeluser.getId();
		
	}

	@Override
	public List<Model1> showall() {
		return model1.findAll();
	
	}

}
