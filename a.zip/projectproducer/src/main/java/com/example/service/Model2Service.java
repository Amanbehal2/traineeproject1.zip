package com.example.service;

import java.util.List;

import com.example.bean1.Model2;

public interface Model2Service {
 
	public int addmodel2User(Model2 model2);
    public List<Model2> showModel2();	
	 
}
