package com.example.UserInterface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean1.Model1;
import com.example.service.Model1Service;


@RestController
@RequestMapping("kafka")
public class Model1Controller {
  
	@Autowired
  private Model1Service model11;
  private int id;
  private String first_Name;
  private String last_Name;
  private String address_1;
  private String address_2;
  private String shopping_Interest;
  @Autowired
  KafkaTemplate<String,Model1> Kafkatemplate;
  private static final String Topic="KafkaProject";
  @GetMapping("/publish/{id}")
  public String post(@PathVariable("id") final int id ) {
	 //  Kafkatemplate.send(Topic,new Model1(id,model12.getFirst_Name(),model12.getLast_Name(),model12.getAddress_1(),model12.getAddress_2(),model12.getShopping_Interests()));
	   Kafkatemplate.send(Topic,new Model1(id,first_Name,last_Name,address_1,address_2,shopping_Interest));
	   return "published";
  }
  
 @GetMapping("/getallModel1")
  public List<Model1> getallModel1(){
	return model11.showall();
 }
  @PostMapping("/createModel1")
  public int createModel1(@RequestBody Model1 model1) {
	 
	 
	  first_Name=model1.getFirst_Name();
		
	  last_Name=model1.getLast_Name();
		
	  address_1=model1.getAddress_1();
	  address_2=model1.getAddress_2();
	  shopping_Interest=model1.getShopping_Interests();
		System.out.println(model1);
		 return model11.adduser(model1);
  }
}
