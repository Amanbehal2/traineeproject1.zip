/*
 * package com.example.UserInterface;
 * 
 * import java.util.List; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.kafka.core.KafkaTemplate; import
 * org.springframework.web.bind.annotation.DeleteMapping; import
 * org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.example.Repo.Model2Repo; import com.example.bean1.Model1; import
 * com.example.bean1.Model2; import com.example.service.model2ServiceImpl;
 * 
 * @RestController
 * 
 * @RequestMapping("/api") public class Model2Controller {
 * 
 * @Autowired private model2ServiceImpl model22;
 * 
 * @Autowired KafkaTemplate<String,Model2> Kafkatemplate; private static final
 * String Topic="model2";
 * 
 * @GetMapping("/publish/{id}") public String post(@PathVariable("id") final int
 * id ) { Kafkatemplate.send(Topic,new Model2(id, "AmanBehl", 123456789,
 * "1233sector1rohtak")); return "published"; }
 * 
 * @GetMapping("/getallModel2") public List<Model2> getallModel2(){ return
 * model22.showModel2(); }
 * 
 * 
 * @PostMapping("/createModel2") public int createModel2(@RequestBody Model2
 * model2) { return model22.addmodel2User(model2); }
 * 
 * }
 */