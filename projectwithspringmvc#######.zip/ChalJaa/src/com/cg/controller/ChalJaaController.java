package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.ChaljaaBean;
import com.cg.service.IBankService;
import com.cg.service.IBankServiceImpl;

@Controller
public class ChalJaaController {

	@Autowired
	IBankService service;

	public IBankService getService() {
		return service;
	}

	public void setService(IBankService service) {
		this.service = service;
	}
			@RequestMapping("/home")
			public String home() {
				return "menu";
			}
	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/submit")
	public String submit(@RequestParam("uname") String uname, @RequestParam("pass") String pass) {
		if ("admin".equals(uname) && "pass".equals(pass)) {
			return "menu";
		} else {
			return "login";
		}
	}
	@RequestMapping("/createAccountform")
	public ModelAndView createAccount() {
		ChaljaaBean acc = new ChaljaaBean();
		return new ModelAndView("createAccountForm", "acc", acc);
	}

	@RequestMapping("/create")
	public ModelAndView create(@ModelAttribute("acc") @Valid ChaljaaBean acc, BindingResult result) {
		ModelAndView mv = null;
		
		if (!result.hasErrors()) {
			ChaljaaBean acc3443=service.createAccount(acc);
			
			mv=new ModelAndView("success","acc",acc3443);
			

		} else {
			
			mv = new ModelAndView("createAccountForm", "acc", acc);
		}
		return mv;

	}
	@RequestMapping("/showBalance")
	public ModelAndView showBalance() {
		double bal=0;
		return new ModelAndView("BalanceForm", "balance", bal);
	}
	@RequestMapping("/money")
	public ModelAndView Balance(@RequestParam("id") long id) {
		ModelAndView mv=null;
		
			double bal=service.ShowBalance(id);
			mv = new ModelAndView("BalanceForm", "balance", bal);
			return mv;
			
	}
	@RequestMapping("/Deposit123")
	public ModelAndView Deposit() {
		ChaljaaBean acc= new ChaljaaBean();
		return new ModelAndView("DepositForm","acc",acc);
	}
	@RequestMapping("/deposit")
	public ModelAndView Deposit12(@RequestParam("id") long id,@RequestParam("balance") double balance) {
		ModelAndView mv=null;
		ChaljaaBean acc12= service.Deposit(balance,id );
        mv=new ModelAndView("DepositForm","acc",acc12);
        return mv;
	}
		@RequestMapping("/withdraw123")
		public ModelAndView withdraw() {
			ChaljaaBean acc= new ChaljaaBean();
			return new ModelAndView("WithdrawForm","acc",acc);
		}
		@RequestMapping("/withdraw")
		public ModelAndView withdraw12(@RequestParam("id") long id,@RequestParam("balance") double balance) {
			ModelAndView mv=null;
			ChaljaaBean acc12=service.withdraw(balance, id);
			mv=new ModelAndView("WithdrawForm","acc",acc12);
			return mv;
		}
		@RequestMapping("/FundTransfer")
		public ModelAndView FundTransfer() {
			ModelAndView mv=null;
			ChaljaaBean acc=new ChaljaaBean();
			mv= new ModelAndView("FundTransfer","acc",acc);
			return mv;
		}
		@RequestMapping("/fundtransfer2")
		public ModelAndView FundTransfered(@RequestParam("account1")long id,@RequestParam("account2")long id1,@RequestParam("money") double balance){
			ModelAndView mv=null;
			ChaljaaBean acc=service.FundTransfer(id, id1, balance);
			mv=new ModelAndView("FundTransfer","acc",acc);
			return mv;
		}
	}

