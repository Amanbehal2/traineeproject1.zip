package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Dao.IBankDao;
import com.cg.Dao.IBankDaoImpl;
import com.cg.beans.ChaljaaBean;

@Service
@Transactional
public class IBankServiceImpl implements IBankService {

	@Autowired
	IBankDao dao;

	public IBankDao getDao() {
		return dao;
	}

	public void setDao(IBankDao dao) {
		this.dao = dao;
	}

	@Override
	public ChaljaaBean createAccount(ChaljaaBean acc) {
		
		return dao.createAccount(acc);
	}

	@Override
	public double ShowBalance(long id) {
		return dao.ShowBalance(id);
	}

	@Override
	public ChaljaaBean Deposit(double money, long id) {
		return dao.Deposit(money, id);
	}

	@Override
	public ChaljaaBean withdraw(double money, long id) {
		
		return dao.withdraw(money, id);
	}

	@Override
	public ChaljaaBean FundTransfer(long id, long id1, double money) {
		
		return dao.FundTransfer(id, id1, money);
	}

	
}
