package com.cg.service;

import com.cg.beans.ChaljaaBean;

public interface IBankService {
	public ChaljaaBean createAccount(ChaljaaBean acc);
	public double ShowBalance(long id);
	public ChaljaaBean Deposit(double money,long id);
	public ChaljaaBean withdraw(double money,long id);
	public ChaljaaBean FundTransfer(long id,long id1,double money);
}
