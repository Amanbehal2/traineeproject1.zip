package com.cg.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.beans.ChaljaaBean;
@Repository
public class IBankDaoImpl implements IBankDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public ChaljaaBean createAccount(ChaljaaBean acc) {
		

		entityManager.persist(acc);
	
		entityManager.flush();
	
		return acc;
	}

	@Override
	public double ShowBalance(long id) {
		
		ChaljaaBean acc1=entityManager.find(ChaljaaBean.class, id);
		double balance=acc1.getBalance();
		
		return balance;
	}

	@Override
	public ChaljaaBean Deposit(double money,long id) {
		
		ChaljaaBean acc2=entityManager.find(ChaljaaBean.class, id);
		double balance=acc2.getBalance()+money;
		acc2.setBalance(balance);
		entityManager.merge(acc2);
		entityManager.flush();
		return acc2;
	}

	@Override
	public ChaljaaBean withdraw(double money,long id) {
		ChaljaaBean acc=entityManager.find(ChaljaaBean.class,id);
		 double balance=acc.getBalance()-money;
		 if(balance >0)
		 {
			 acc.setBalance(balance);
		 }
		 else {
			 return acc;
		 }
		return acc;
	}

	@Override
	public ChaljaaBean FundTransfer(long id,long id1,double money) {
	
		
		ChaljaaBean acc=entityManager.find(ChaljaaBean.class, id);
	
		double balance=acc.getBalance()-money;
		acc.setBalance(balance);
		entityManager.merge(acc);
		entityManager.flush();
		ChaljaaBean acc1=entityManager.find(ChaljaaBean.class, id1);
	double balance1=acc1.getBalance()+money;
	 acc1.setBalance(balance1);
	 entityManager.merge(acc1);
	 entityManager.flush();
	 return acc;
		
	}

	@Override
	public ChaljaaBean PrintTransactions(ChaljaaBean acc) {
		
		return null;
	}

}
