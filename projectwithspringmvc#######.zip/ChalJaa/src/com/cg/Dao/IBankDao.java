package com.cg.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.beans.ChaljaaBean;

public interface IBankDao {

	
	
	public ChaljaaBean createAccount(ChaljaaBean acc);
	public double ShowBalance(long id);
	public ChaljaaBean Deposit(double money,long id);
	public ChaljaaBean withdraw(double money,long id);
	public ChaljaaBean FundTransfer(long id,long id1,double money);
	public ChaljaaBean PrintTransactions(ChaljaaBean acc);
	
	
}
