package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.bean.TraineeBean;

public interface ITraineeService {
	public TraineeBean addTrainee(TraineeBean trainee);
	public List<TraineeBean> getAllTraineeDetails();
	public TraineeBean getaTraineeDetails(int traineeId);
}
