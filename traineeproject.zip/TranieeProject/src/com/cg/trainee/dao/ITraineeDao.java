package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.bean.TraineeBean;

public interface ITraineeDao {
	public TraineeBean addTrainee(TraineeBean trainee);
	public TraineeBean getaTraineeDetails(int traineeId);
	public List<TraineeBean> getAllTraineeDetails();
}
