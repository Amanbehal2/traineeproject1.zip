package com.cg.trainee.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.TraineeBean;
@Repository
public class ITraineeDaoImpl implements ITraineeDao{
	
		
		@PersistenceContext
		private EntityManager entityManager;

	



	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public List<TraineeBean> getAllTraineeDetails() {
		// TODO Auto-generated method stub
		TypedQuery<TraineeBean> query = entityManager.createQuery("SELECT d FROM TraineeBean d", TraineeBean.class);
		return query.getResultList();
	}

	@Override
	public TraineeBean getaTraineeDetails(int traineeId) {
		// TODO Auto-generated method stub
		return entityManager.find(TraineeBean.class, traineeId);
	}
}
