package com.cg.repo;

import java.time.LocalDate;
import com.cg.bean.Account;
import com.cg.bean.Transaction;

public interface IBankDAO {
	public void createAccount(Account a);
	public void showBalance(long accno);
	public void deposit(long accno, double depamm, Transaction t);
	public void withdraw(long accno, double withamm, Transaction t);
	public void transfer(double transamm, long accno, long accno2, Transaction t);
	public void showTransactions(long accno);
}
