package com.cg.repo;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.util.ConnectionFactory;

public class BankDAOImpl implements IBankDAO {
	private Connection con=null;
	private PreparedStatement ps=null;
	private PreparedStatement qs=null;
	private PreparedStatement ts=null;
	private PreparedStatement ss=null;
	private PreparedStatement us=null;
	public void getConnection() throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		
		
	}
	
	/*create table Account(AccNo number primary key, AccName varchar2(30), Mobile number, Address varchar2(50),
	 Balance number, Foreign Key (Account) REFERENCES Transactions(Account));
	 */
	
	public void createAccount(Account a) {
		
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			ps=con.prepareStatement(QUERRY_MAPPING.INSERT_VAL);
			System.out.println(a);
			ps.setString(1, a.getName());
			ps.setLong(2, a.getMobile());
			ps.setString(3, a.getAddr());
			ps.setDouble(4, a.getBalance());
			ps.executeUpdate();
			System.out.println("Account Created");
			//System.out.println("Your Account Number Is "+a.getAccNumber());
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

	@Override
	public void showBalance(long accno) {
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			ps=con.prepareStatement(QUERRY_MAPPING.SELECT_VAL);
			ps.setLong(1, accno);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				System.out.println("Account Number: "+rs.getInt(1));
				System.out.println("Balance: "+rs.getDouble(2));
			}
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void deposit(long accno, double depamm, Transaction t) {
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			double balance = 0;
			ps=con.prepareStatement(QUERRY_MAPPING.UPDATE_VAL);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				if(rs.getLong(1)==accno) {
					balance=rs.getDouble(2);
					balance=balance+depamm;
				}
			}
		    ps.setDouble(1, balance);
		    ps.setLong(2, accno);
		    ps.executeUpdate();
			ts=con.prepareStatement(QUERRY_MAPPING.TRANS_INSERT_VAL);
			ts.setDouble(1, balance);
			ts.setLong(2, accno);
			ts.executeUpdate();	
			System.out.println(depamm+" Deposited To "+accno);
			qs=con.prepareStatement("");
			qs.setLong(1, accno);
			qs.setDouble(2, depamm);
			qs.setString(3, "Deposit");
			qs.setDate(4, Date.valueOf(LocalDate.now()));
			qs.setTime(5, Time.valueOf(LocalTime.now()));
			qs.executeUpdate();
			con.close();
			}catch(Exception e) {
				System.out.println(e);
		}
		
	}

	@Override
	public void withdraw(long accno, double withamm, Transaction t) {
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			double balance = 0;
			ps=con.prepareStatement(QUERRY_MAPPING.VIEW_ALL);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				if(rs.getLong(1)==accno) {
					balance=rs.getDouble(5);
					balance=balance-withamm;
				}
			}
			ts=con.prepareStatement(QUERRY_MAPPING.UPDATE_VAL);
			ts.setDouble(1, balance);
			ts.setLong(2, accno);
			ts.executeUpdate();	
			System.out.println(withamm+" Withdrawn From "+accno);
			qs=con.prepareStatement(QUERRY_MAPPING.TRANS_INSERT_VAL);
			qs.setLong(1, accno);
			qs.setDouble(2, withamm);
			qs.setString(3, "Withdraw");
			qs.setDate(4, Date.valueOf(LocalDate.now()));
			qs.setTime(5, Time.valueOf(LocalTime.now()));
			qs.executeUpdate();
			con.close();
			}catch(Exception e) {
				System.out.println(e);
		}
		
	}

	@Override
	public void transfer(double transamm, long accno, long accno2, Transaction t) {
		try {
			con=ConnectionFactory.getSigtonObj().getConnection();
			double balance = 0;
			ps=con.prepareStatement(QUERRY_MAPPING.SELECT_VAL);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				if(rs.getLong(1)==accno) {
					balance=rs.getDouble(5);
					balance=balance-transamm;
				}
				if(rs.getLong(1)==accno2) {
					balance=rs.getDouble(5);
					balance=balance+transamm;
				}
			}
			ts=con.prepareStatement(QUERRY_MAPPING.UPDATE_VAL);
			ts.setDouble(1, balance);
			ts.setLong(2, accno);
			ts.executeUpdate();	
			System.out.println(transamm+" Transferred From "+accno);
			
			ss=con.prepareStatement(QUERRY_MAPPING.UPDATE_VAL);
			ss.setDouble(1, balance);
			ss.setLong(2, accno2);
			ss.executeUpdate();	
			System.out.println(transamm+" Transferred To "+accno2);
			
			qs=con.prepareStatement(QUERRY_MAPPING.TRANS_INSERT_VAL);
			String type="Transfer To "+accno2+"";
			qs.setLong(1, accno);
			qs.setDouble(2, transamm);
			qs.setString(3, type);
			qs.setDate(4, Date.valueOf(LocalDate.now()));
			qs.setTime(5, Time.valueOf(LocalTime.now()));
			qs.executeUpdate();
			
			us=con.prepareStatement(QUERRY_MAPPING.TRANS_INSERT_VAL);
			type="Transfer From "+accno+"";
			us.setLong(1, accno2);
			us.setDouble(2, transamm);
			us.setString(3, type);
			us.setDate(4, Date.valueOf(LocalDate.now()));
			us.setTime(5, Time.valueOf(LocalTime.now()));
			us.executeUpdate();
			con.close();
			}catch(Exception e) {
				System.out.println(e);
		}
	}

	@Override
	public void showTransactions(long accno) {
		try {
			getConnection();
			ps=con.prepareStatement(QUERRY_MAPPING.GET_TRANSACTION);
			ps.setLong(1, accno);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				System.out.print("Account Number: "+rs.getLong(1)+" || ");
				System.out.print("Balance: "+rs.getDouble(2)+" || ");
				System.out.print("Transaction Type: "+rs.getString(3)+" || ");
				System.out.print("Date: "+rs.getDate(4)+" || ");
				System.out.print("Time: "+rs.getTime(5));
				System.out.println();
			}
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}


}
