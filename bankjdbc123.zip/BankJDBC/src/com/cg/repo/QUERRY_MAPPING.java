package com.cg.repo;

public class QUERRY_MAPPING {

	public static final String INSERT_VAL="INSERT INTO account VALUES(ACCNOSEQ1.NEXTVAL,?,?,?,?)";
	public static final String SELECT_VAL="SELECT Id,balance FROM account WHERE Id=?";
	public static final String VIEW_ALL="SELECT * FROM account";
	public static final String UPDATE_VAL="UPDATE account SET balance=? WHERE Id=?";
	public static final String TRANS_INSERT_VAL="INSERT INTO Transaction VALUES(?,?,?,?,?)";
    public static final String GET_TRANSACTION="SELECT * FROM Transaction WHERE Id=?";
}
