package com.cg.service;

import java.time.LocalDate;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.repo.BankDAOImpl;
import com.cg.repo.IBankDAO;

public class BankServiceImpl implements IBankService{
	IBankDAO acc=new BankDAOImpl();

	@Override
	public void createAccount(Account a) {
	//	System.out.println(a);
		acc.createAccount(a);
	}

	@Override
	public void showBalance(long accno) {
		acc.showBalance(accno);
	}

	@Override
	public void deposit(long accno, double depamm, Transaction t) {
		acc.deposit(accno, depamm, t);
	}

	@Override
	public void withdraw(long accno, double withamm, Transaction t) {
		acc.withdraw(accno, withamm, t);
	}

	@Override
	public void transfer(double transamm, long accno, long accno2, Transaction t) {
		acc.transfer(transamm, accno, accno2, t);
	}

	@Override
	public void showTransactions(long accno) {
		acc.showTransactions(accno);
	}

}
