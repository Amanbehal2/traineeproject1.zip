package com.cg.bean;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

public class Transaction {
	private Date dd;
	private Time tt;
	private long accno;
	private double amount;
	private String type;
	public Date getDd() {
		return dd;
	}
	public void setDd(Date dd) {
		this.dd = dd;
	}
	public Time getTt() {
		return tt;
	}
	public void setTt(Time tt) {
		this.tt = tt;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Transaction [dd=" + dd + ", tt=" + tt + ", accno=" + accno + ", amount=" + amount + ", type=" + type
				+ "]";
	}
	
}
