package com.cg.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.service.BankServiceImpl;
import com.cg.service.IBankService;


public class BankUI {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		IBankService service=new BankServiceImpl();
		
		Transaction t=new Transaction();
		while(true) {
			System.out.println("\nEnter Your Choice: ");
			System.out.println("1. Create New Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Transfer Amount");
			System.out.println("6. Show Transactions");
			System.out.println("7. Exit");
			int m=sc.nextInt();
			switch(m) {
			case 1:	
				Account a=new Account();
				System.out.println("Enter Name: ");
				a.setName(sc.next());
				
				System.out.println("Enter Mobile Number: ");
				Long mobile1=sc.nextLong();
				String mobile=String.valueOf(mobile1);
				if(mobile.matches("[0-9]{10}")) {
					a.setMobile(mobile1);
				}
				else {
					System.out.println("Enter A Valid Mobile Number: 10 Digits, Positive Integer");
					break;
				}
				System.out.println("Enter E-Mail Address: ");
				String email1=sc.next();
				if(email1.matches("[a-zA-Z0-9[!#$%&'()*+,/\\-_\\.\"]]+@[a-zA-Z0-9[!#$%&'()*+,/\\-_\"]]+\\.[a-zA-Z0-9[!#$%&'()*+,/\\-_\"\\.]]+")) {
					a.setAddr(email1);
				}
				else {
					System.out.println("Enter A Valid E-Mail");
					break;
				}
				System.out.println("Enter Initial Balance: ");
				a.setBalance(sc.nextDouble());
				service.createAccount(a);
				break;
			case 2:
				System.out.println("Enter Account Number: ");
				long accno2=sc.nextLong();
				service.showBalance(accno2);
				break;
			case 3:
				System.out.println("Enter Account Number: ");
				long accno3=sc.nextLong();
				System.out.println("Enter Amount To Be Deposited: ");
				double depamm3=sc.nextDouble();
				service.deposit(accno3, depamm3, t);
				break;
			case 4:
				System.out.println("Enter Account Number: ");
				long accno4=sc.nextLong();
				System.out.println("Enter Amount To Be Withdrawn: ");
				double withamm4=sc.nextDouble();
				service.withdraw(accno4, withamm4, t);
				break;
			case 5:
				System.out.println("Enter Account Number From Which Amount Is To Be Transferred: ");
				long accno5=sc.nextLong();
				System.out.println("Enter Account Number Into Which Amount Is To Be Transferred: ");
				long accno25=sc.nextLong();
				System.out.println("Enter Amount To Be Transferred: ");
				double transamm5=sc.nextDouble();
				service.transfer(transamm5, accno5, accno25, t);
				break;
			case 6:
				System.out.println("Enter Account Number: ");
				long accno6=sc.nextLong();
				service.showTransactions(accno6);
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Input");
				break;
			}
		}
	}
	
}
