package com.dao;

import com.Bean.Employee;

public interface IEMployeeDaoImpl {

	public void addEmployee(Employee emp);
	public Employee getallEmployee();
	public void deleteEmployee(int id); 
	
}
