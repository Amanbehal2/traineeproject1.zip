package com.dao;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.Bean.Employee;
@Repository
public class EmloyeeDao implements IEMployeeDaoImpl {

	   private EntityManager entitymanager;
	
	
	@Override
	public void addEmployee(Employee emp) {
		entitymanager.persist(emp);
		entitymanager.flush();
	}

	@Override
	public Employee getallEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}
