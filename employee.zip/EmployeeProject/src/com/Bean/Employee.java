package com.Bean;

public class Employee {

	private int id;
	private String EmpName;
	private String Department;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		Department = department;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", EmpName=" + EmpName + ", Department=" + Department + "]";
	}
	
	
}
