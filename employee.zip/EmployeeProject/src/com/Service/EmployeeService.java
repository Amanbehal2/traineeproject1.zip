package com.Service;

import com.Bean.Employee;

public interface EmployeeService {

	public void addEmployee(Employee emp);
	public Employee getallEmployee();
	public void deleteEmployee(int id); 
	
}
