package com.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Bean.Employee;
import com.Service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService service;

	public EmployeeService getService() {
		return service;
	}

	public void setService(EmployeeService service) {
		this.service = service;
	}
	@RequestMapping("/showHome")
	public String showHome() {
		return "Login";
		
	}
	@RequestMapping("/login")
	public String login(@RequestParam("uname") String uname,@RequestParam("pass") String pass,Model model) 
		{	System.out.println(uname+" "+pass);
        if(uname.trim().equals("Employee") && pass.equals("password"))  
        {  
          String msg="Hello "+ uname;  
           model.addAttribute("message", msg); 
           return "Menu";
        }
        else {
        	return "Login";
        }
         
	}
	@RequestMapping("/addEmployee")
	public ModelAndView showAdd() {
		
		Employee emp=new Employee();
		return new ModelAndView("AddEmployee","employee",emp);
	}
		@RequestMapping("/AddEmployee1")
		public ModelAndView addEmployee(@ModelAttribute("employee") Employee emp,BindingResult result) {
			ModelAndView mv= new ModelAndView();
			
			if (!result.hasErrors())
			{
				service.addEmployee(emp);
				mv = new ModelAndView("Success");
			/*	mv.addObject("traineeId", trainee.getTraineeId());
				mv.addObject("traineeName",trainee.getTraineeName());
				mv.addObject("traineeId", trainee.getTraineeDomain());
				mv.addObject("traineeName",trainee.getTraineeLocation());*/
			} else {
				mv = new ModelAndView("AddEmployee", "employee", emp); 
			}

			return mv;
			
}
}